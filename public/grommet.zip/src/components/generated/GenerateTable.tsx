import React, { useState } from 'react';
import CustomerTable from './GeneratedData';
import { useAllUtilizationQuery } from './../../generated/graphql'
const GeneratedTable = () => {
  const [result] = useAllUtilizationQuery()
  const { data, error, fetching } = result;

  if (error) return <p>Oh no... {error.message}</p>;
  console.log(data)
  return (<>
    <CustomerTable utilization={fetching ? [] : data?.utilization} />
  </>
  );
};
export default GeneratedTable
