import React, { useState } from 'react'
import { useIntl, FormattedMessage } from "react-intl";
import { DataGrid } from "@material-ui/data-grid";
export default function CustomerTable({ utilization }: any) {
  const intl = useIntl();
  const columns = [
    { field: "id", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },
    { field: "name", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },
    { field: "availableValue", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },
    { field: "available", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },
    { field: "usedValue", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },
    { field: "value", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },
    { field: "used", flex: 1, type: "string", valueFormatter: ({ value }: any) => value },


  ];
  return (<div style={{ height: "400px", width: "100%" }}><DataGrid columns={columns} rows={utilization} /></div>);
}