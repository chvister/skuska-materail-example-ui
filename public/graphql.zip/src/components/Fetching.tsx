import React from 'react';

const Fetching: React.FC = ({ }) => {

  return (
    <>
      fetching
    </>
  )
}

export default Fetching
