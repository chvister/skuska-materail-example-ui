export interface ICustomer {
    avatarUrl: string;
    createdAt: number;
    email: string;
    name: string;
    phone: string;
    updatedAt: number;
    test2: number;
  }