import data from '../product/ProductListView/data'
import React, { useState } from 'react';
import GeneratedProductsTable from './GeneratedProductsTable'

const GeneratedProducts = () => {
  const [products] = useState(data);
  console.log(products)
  return (
    < GeneratedProductsTable products={products} />
  );
};
export default GeneratedProducts
