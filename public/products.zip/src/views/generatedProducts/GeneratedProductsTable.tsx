import React from "react";
import { useIntl, FormattedMessage } from "react-intl";
import { GridColParams, DataGrid } from "@material-ui/data-grid";
import { useNavigate } from "react-router-dom";
export default function GeneratedProductsTable({ products }) {
  let navigate = useNavigate();
  const intl = useIntl();
  const columns = [
    { field: "description", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => (<FormattedMessage id="product.description" defaultMessage="Description" />) },
    { field: "title", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => (<FormattedMessage id="product.title" defaultMessage="title" />) },
    { field: "media", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => (<FormattedMessage id="product.media" defaultMessage="media" />) },
    { field: "id", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => (<FormattedMessage id="product.id" defaultMessage="id" />) },
    { field: "totalDownloads", flex: 1, type: "string", valueFormatter: ({ value }) => value, renderHeader: (params: GridColParams) => (<FormattedMessage id="product.totalDownloads" defaultMessage="totalDownloads" />) }
  ];
  return (<div style={{ height: "400px", width: "100%" }}><DataGrid columns={columns} rows={products} /></div>);
}


